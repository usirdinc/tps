import os
import shutil
from pypdf import PdfReader

months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
family = []

def extract_biometrics_appointment(file):
    try:
        pdf = PdfReader(file)
        page_text = pdf.pages[0].extract_text()

        # Extracting the applicant's name
        try:
            name_section = page_text.split("ACCOUNT NUMBER USCIS A#")[1]
            name = name_section.split("PLEASE READ THIS ENTIRE NOTICE CAREFULLY.")[0].strip().split("\n")[4].title()
        except IndexError:
            raise ValueError("Error extracting name from the PDF.")

        # Extracting the location and date/time of appointment
        try:
            main_text = page_text.split("APPLICATION SUPPORT CENTER")[1].split("WHEN")[0].split("DATE AND TIME OF APPOINTMENT\n")
            location = main_text[0].replace("  ", " ").replace("\n", " ").strip()
            date_raw = main_text[1].split("\n")[0]
            date = f"{months[int(date_raw.split('/')[0]) - 1]} {date_raw.split('/')[1].lstrip('0')}, {date_raw.split('/')[2]}"
            time = main_text[1].split("\n")[1]
        except IndexError:
            raise ValueError("Error extracting appointment details from the PDF.")

        data = f"Location: {location}\nDate: {date}\nTime: {time}\n"
        filename = f"Biometrics Appointment - {name}.pdf"

        return name, data, filename, 1
    except Exception as e:
        print(f"Error processing file {file}: {e}")
        return None, None, None, 1

def extract_receipt_notice(file):
    try:
        pdf = PdfReader(file)
        page_text = pdf.pages[0].extract_text()

        data = ""
        aNumbers = []
        names = []

        main_text = page_text.split("Applicant(s):\nAlien Number Name")[1].split("\nPlease see the additional")[0].split("\n")
        for main_line in main_text:
            if len(main_line) > 1:
                aNumber = "".join([main_line.split(" ")[0], main_line.split(" ")[1], main_line.split(" ")[2]])
                name_array = main_line.split(main_line.split(" ")[2] + " ")[1].split(", ")
                aNumbers.append(aNumber)
                names.append(name_array[1].title() + " " + name_array[0].title())

        for name in names:
            data += name + " " + aNumbers[names.index(name)] + "\n"

        if(len(data.split("\n")) > 2):
            familymembers = []
            for familymember in data.split("\n"):
                familymember = familymember.split(" ")
                familymember.pop()
                familymembers.append(" ".join(familymember))
            familymembers.pop()
            family.append(familymembers)

        filename = "Receipt Notice - " + names[0] + ".pdf"

        return names[0], data, filename, 0
    except Exception as e:
        print(f"Error processing file {file}: {e}")
        return None, None, None, 0

def extract_i589(file):
    try:
        pdf = PdfReader(file)
        page_text = pdf.pages[0].extract_text()
        data = "i-589"
        main_text = page_text.split("Executive Office for Immigration Review\n")[1].split("Applicant:")[0].split("\n")[0].removesuffix(" ")
        names = [main_text]
        filename = f"I589 - {names[0]}.pdf"
        return names[0], data, filename, 2
    except Exception as e:
        print(f"Error processing file {file}: {e}")
        return None, None, None, 2

functions = [extract_receipt_notice, extract_biometrics_appointment, extract_i589]
keyWords = ["Notice Type: Receipt Notice", "WHEN YOU APPEAR AT THE ASC FOR BIOMETRICS SUBMISSION, YOU MUST BRING", "Do you also want to apply for withholding of removal under the Convention Against Torture?"]
folderNames = ["Receipt Notice", "Biometrics Appointment", "I-589"]
data = [[],[],[]]

def finalize(group, file, index):
    if not group[0] or not group[1] or not group[2]:
        print(f"Skipping file {file} due to extraction errors.")
        return

    if not os.path.exists(folderNames[index]):
        os.mkdir(folderNames[index])

    new_location = os.path.join(folderNames[index], group[2])
    shutil.move(file, new_location)

files = [file for file in os.listdir() if file.endswith(".pdf")]

def __main__(files):
    for file in files:
        for keyWord in keyWords:
            if PdfReader(file).pages[0].extract_text().find(keyWord) != -1:
                finalize(functions[keyWords.index(keyWord)](file), file, keyWords.index(keyWord))
                break


__main__(files)

